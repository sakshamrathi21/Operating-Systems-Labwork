#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int *base_ptr;
    int pid = getpid();
    printf(1, "Before allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));
    base_ptr = (int *)allocro(1);
    printf(1, "After allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));

    // Trying to read from the memory pointed by base_ptr
    printf(1, "Value at allocated address 0x%x is %d\n", base_ptr, *base_ptr);

    // Trying to write to the memory pointed by base_ptr, this should generate page fault
    *base_ptr = 5;

    // Checking the value at base_ptr after write, to check if the pagefault is handled properly
    printf(1, "Value at allocated address 0x%x after write is %d\n", base_ptr, *base_ptr);

    printf(1, "Before sbrk\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));
    int *n = (int *)sbrk(4096);
    printf(1, "After sbrk\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));

    printf(1, "Value at allocated address 0x%x is %d\n", n, *n);
    *n = 15;
    printf(1, "Value at allocated address 0x%x after write is %d\n", n, *n);

    printf(1, "Before allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));
    base_ptr = (int *)allocro(2);
    printf(1, "After allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));

    printf(1, "Value at allocated address 0x%x is %d\n", base_ptr, *base_ptr);

    *base_ptr = 10;

    printf(1, "Value at allocated address 0x%x after write is %d\n", base_ptr, *base_ptr);

    exit();
}