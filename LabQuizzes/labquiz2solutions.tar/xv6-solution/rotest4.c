#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int *base_ptr;
    int pid = getpid();

    printf(1, "Before allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));
    base_ptr = (int *)allocro(1);
    printf(1, "After allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));

    base_ptr += (1024 * 5);
    
    *base_ptr = 5;
    printf(1, "Value at allocated address 0x%x after write is %d\n", base_ptr, *base_ptr);

    exit();
}