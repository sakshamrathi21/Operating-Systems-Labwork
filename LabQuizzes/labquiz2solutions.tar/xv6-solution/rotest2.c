#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[])
{
    int *base_ptr;
    int *addr_ptr;
    int pid = getpid();

    printf(1, "Before allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));
    base_ptr = (int *)allocro(3);
    printf(1, "After allocro\tV: %d | P: %d\n", getvasize(pid), getpasize(pid));

    *base_ptr = 5;

    addr_ptr = base_ptr;

    for (int i = 0; i < 3; i++)
    {
        printf(1, "Value at allocated address 0x%x is %d\n", addr_ptr, *addr_ptr);
        addr_ptr += 1024;
    }

    *(base_ptr + (1024 * 2)) = 5;

    addr_ptr = base_ptr;
    for (int i = 0; i < 3; i++)
    {
        printf(1, "Value at allocated address 0x%x is %d\n", addr_ptr, *addr_ptr);
        addr_ptr += 1024;
    }

    *(base_ptr + 1024) = 5;

    addr_ptr = base_ptr;
    for (int i = 0; i < 3; i++)
    {
        *addr_ptr = 10;
        printf(1, "Value at allocated address 0x%x is %d\n", addr_ptr, *addr_ptr);
        addr_ptr += 1024;
    }

    exit();
}