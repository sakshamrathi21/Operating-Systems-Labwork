#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include <map>

#include "alloc.h"

using namespace std;

int init_alloc(){

}

int cleanup(){

}

char *alloc(int size){

}

void dealloc(char* f_mem){

}
